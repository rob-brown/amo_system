sshfs -o allow_other raspi:/home/pi/projects/switch/joycontrol/ remote_joycontrol/
